package com.redproex.rustyworld

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val ComponentActivity.dataStore by preferencesDataStore(name = "rusty_world_store")
private val NotesKey = stringPreferencesKey("notes_json")
private val ChaptersKey = stringPreferencesKey("chapters_json")

private val BlueScheme = lightColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFF0B57D0), onPrimary = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
    primaryContainer = androidx.compose.ui.graphics.Color(0xFFD3E3FD), onPrimaryContainer = androidx.compose.ui.graphics.Color(0xFF041E49),
    secondary = androidx.compose.ui.graphics.Color(0xFF5A5C7C), onSecondary = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
    secondaryContainer = androidx.compose.ui.graphics.Color(0xFFDCE2F9), onSecondaryContainer = androidx.compose.ui.graphics.Color(0xFF131C2B),
    tertiary = androidx.compose.ui.graphics.Color(0xFF76516A), onTertiary = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
    tertiaryContainer = androidx.compose.ui.graphics.Color(0xFFFFD8EE), onTertiaryContainer = androidx.compose.ui.graphics.Color(0xFF2E1125),
    background = androidx.compose.ui.graphics.Color(0xFFFAF9FD), onBackground = androidx.compose.ui.graphics.Color(0xFF1B1B1F),
    surface = androidx.compose.ui.graphics.Color(0xFFFAF9FD), onSurface = androidx.compose.ui.graphics.Color(0xFF1B1B1F),
    surfaceVariant = androidx.compose.ui.graphics.Color(0xFFE3E2E6), onSurfaceVariant = androidx.compose.ui.graphics.Color(0xFF44474E),
    surfaceContainerLowest = androidx.compose.ui.graphics.Color(0xFFFFFFFF), surfaceContainerLow = androidx.compose.ui.graphics.Color(0xFFF3F3FA),
    surfaceContainer = androidx.compose.ui.graphics.Color(0xFFEEEDF3), surfaceContainerHigh = androidx.compose.ui.graphics.Color(0xFFE9E8EF),
    surfaceContainerHighest = androidx.compose.ui.graphics.Color(0xFFE3E2E6), outline = androidx.compose.ui.graphics.Color(0xFF74777F),
    outlineVariant = androidx.compose.ui.graphics.Color(0xFFC4C6D0), inverseSurface = androidx.compose.ui.graphics.Color(0xFF303034),
    inverseOnSurface = androidx.compose.ui.graphics.Color(0xFFF2F0F4), inversePrimary = androidx.compose.ui.graphics.Color(0xFFA8C7FA),
    error = androidx.compose.ui.graphics.Color(0xFFB3261E), onError = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
    errorContainer = androidx.compose.ui.graphics.Color(0xFFF9DEDC), onErrorContainer = androidx.compose.ui.graphics.Color(0xFF410E0B)
)

private enum class Page { HOME, PROJECT, CHARACTERS, HISTORY, READ, FEEDBACK, NOTES }
private data class Work(val title: String, val subtitle: String, val kind: String)
private val works = listOf(
    Work("RED_CLASH of RED_PARK", "Мобильная командная арена", "game"),
    Work("The Rusty World", "Общее название книжной вселенной", "world"),
    Work("Gold Child", "История о золотой руке и Эребе", "book"),
    Work("Gold World", "Продолжение истории; Пека и пять сюжетных линий", "book")
)
private val characterNames = listOf("Пека", "Шторм", "Алексей", "Элли Рояль", "Ред", "Тревор", "Эреб")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = BlueScheme, typography = Typography(), motionScheme = MotionScheme.standard()) {
                RustyWorldApp(onFeedback = { subject, body ->
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:redprofeedback@gmail.com")
                        putExtra(Intent.EXTRA_SUBJECT, subject)
                        putExtra(Intent.EXTRA_TEXT, body)
                    }
                    runCatching { startActivity(intent) }
                })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RustyWorldApp(onFeedback: (String, String) -> Unit) {
    var page by remember { mutableStateOf(Page.HOME) }
    var selectedWork by remember { mutableStateOf(works[0]) }
    var search by remember { mutableStateOf("") }
    var newTitle by remember { mutableStateOf("") }
    var newText by remember { mutableStateOf("") }
    var feedbackSubject by remember { mutableStateOf("") }
    var feedbackBody by remember { mutableStateOf("") }
    var showDeleteDialog by remember { mutableStateOf<String?>(null) }
    var notes by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var chapters by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = (context as? ComponentActivity)?.dataStore

    LaunchedEffect(store) {
        store?.data?.map { prefs ->
            val ns = mutableListOf<Pair<String, String>>()
            val cs = mutableListOf<Pair<String, String>>()
            runCatching { JSONArray(prefs[NotesKey] ?: "[]").let { a -> for (i in 0 until a.length()) { val o = a.getJSONObject(i); ns += o.optString("title") to o.optString("text") } } }
            runCatching { JSONArray(prefs[ChaptersKey] ?: "[]").let { a -> for (i in 0 until a.length()) { val o = a.getJSONObject(i); cs += o.optString("title") to o.optString("text") } } }
            ns to cs
        }?.collect { (n, c) -> notes = n; chapters = c }
    }

    fun persist(items: List<Pair<String, String>>, key: androidx.datastore.preferences.core.Preferences.Key<String>) {
        val array = JSONArray()
        items.forEach { (title, text) -> array.put(JSONObject().put("title", title).put("text", text)) }
        scope.launch { store?.edit { it[key] = array.toString() } }
    }
    fun goBack() { page = when (page) { Page.HOME -> Page.HOME; else -> Page.HOME } }
    BackHandler(enabled = page != Page.HOME) { goBack() }

    Scaffold(containerColor = MaterialTheme.colorScheme.surface, topBar = {
        if (page != Page.HOME) {
            TopAppBar(
                title = { Text(when (page) { Page.PROJECT -> selectedWork.title; Page.CHARACTERS -> "Персонажи"; Page.HISTORY -> "История"; Page.READ -> "Читать"; Page.FEEDBACK -> "Обратная связь"; Page.NOTES -> "Мои заметки"; else -> "Ржавый мир" }, maxLines = 1) },
                navigationIcon = { IconButton(onClick = { goBack() }) { Icon(Icons.Rounded.ArrowBack, contentDescription = "Назад") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    }) { padding ->
        AnimatedContent(targetState = page, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "page", modifier = Modifier.padding(padding)) { current ->
            when (current) {
                Page.HOME -> HomeScreen(
                    onWork = { selectedWork = it; page = Page.PROJECT },
                    onCharacters = { page = Page.CHARACTERS }, onHistory = { page = Page.HISTORY },
                    onRead = { page = Page.READ }, onFeedback = { page = Page.FEEDBACK }, onNotes = { page = Page.NOTES }
                )
                Page.PROJECT -> ProjectScreen(selectedWork, onRead = { page = Page.READ }, onNotes = { page = Page.NOTES })
                Page.CHARACTERS -> CharactersScreen(search, { search = it })
                Page.HISTORY -> HistoryScreen(notes, newTitle, { newTitle = it }, newText, { newText = it },
                    onSave = { val title = newTitle.trim(); val body = newText.trim(); if (title.isNotEmpty() && body.isNotEmpty()) { val updated = notes + (title to body); notes = updated; persist(updated, NotesKey); newTitle = ""; newText = "" } },
                    onDelete = { showDeleteDialog = it })
                Page.READ -> ReadScreen(chapters, newTitle, { newTitle = it }, newText, { newText = it },
                    onSave = { val title = newTitle.trim(); val body = newText.trim(); if (title.isNotEmpty() && body.isNotEmpty()) { val updated = chapters + (title to body); chapters = updated; persist(updated, ChaptersKey); newTitle = ""; newText = "" } },
                    onDelete = { showDeleteDialog = it })
                Page.FEEDBACK -> FeedbackScreen(feedbackSubject, { feedbackSubject = it }, feedbackBody, { feedbackBody = it },
                    onSend = { if (feedbackSubject.isNotBlank() && feedbackBody.isNotBlank()) onFeedback(feedbackSubject.trim(), feedbackBody.trim()) })
                Page.NOTES -> NotesScreen(notes, onDelete = { showDeleteDialog = it })
            }
        }
    }
    showDeleteDialog?.let { item ->
        AlertDialog(onDismissRequest = { showDeleteDialog = null }, title = { Text("Удалить запись?") },
            text = { Text("«$item» будет удалено с этого устройства.") },
            confirmButton = { TextButton(onClick = {
                val updatedNotes = notes.filterNot { it.first == item }
                val updatedChapters = chapters.filterNot { it.first == item }
                if (updatedNotes.size != notes.size) { notes = updatedNotes; persist(updatedNotes, NotesKey) }
                if (updatedChapters.size != chapters.size) { chapters = updatedChapters; persist(updatedChapters, ChaptersKey) }
                showDeleteDialog = null
            }) { Text("Удалить", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { showDeleteDialog = null }) { Text("Отмена") } }, shape = RoundedCornerShape(28.dp))
    }
}

@Composable
private fun HomeScreen(onWork: (Work) -> Unit, onCharacters: () -> Unit, onHistory: () -> Unit, onRead: () -> Unit, onFeedback: () -> Unit, onNotes: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("ТВОЯ ВСЕЛЕННАЯ", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Text("Ржавый мир", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Игры, книги и истории Redproex", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { onWork(works[0]) }, contentPadding = PaddingValues(horizontal = 10.dp), shape = RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp, topEnd = 8.dp, bottomEnd = 8.dp), modifier = Modifier.weight(1.35f)) { Text("RED_CLASH of RED_PARK", style = MaterialTheme.typography.labelMedium, maxLines = 2) }
            OutlinedButton(onClick = { onWork(works[1]) }, contentPadding = PaddingValues(horizontal = 10.dp), shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) { Text("The Rusty World", style = MaterialTheme.typography.labelMedium, maxLines = 2) }
            Button(onClick = { onWork(works[1]) }, contentPadding = PaddingValues(horizontal = 8.dp), shape = RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp, topEnd = 28.dp, bottomEnd = 28.dp), modifier = Modifier.weight(.32f)) { Text("•••") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onWork(works[2]) }, modifier = Modifier.weight(1f)) { Text("Gold child", maxLines = 1) }
            Button(onClick = { onWork(works[3]) }, modifier = Modifier.weight(1f)) { Text("Gold World", maxLines = 1) }
        }
        Spacer(Modifier.height(2.dp))
        Button(onClick = onCharacters, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 20.dp)) { Icon(Icons.Rounded.Person, null); Spacer(Modifier.width(8.dp)); Text("Персонажи") }
        Button(onClick = onHistory, modifier = Modifier.width(132.dp)) { Text("История") }
        Spacer(Modifier.weight(1f))
        Button(onClick = onRead, modifier = Modifier.fillMaxWidth().height(84.dp), shape = RoundedCornerShape(42.dp)) {
            Icon(Icons.Rounded.Logout, contentDescription = null, modifier = Modifier.size(24.dp)); Spacer(Modifier.width(12.dp)); Text("Читать", style = MaterialTheme.typography.titleLarge)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onNotes) { Icon(Icons.Rounded.BookmarkBorder, null); Spacer(Modifier.width(6.dp)); Text("Мои записи") }
            FilledTonalButton(onClick = onFeedback, modifier = Modifier.height(32.dp), contentPadding = PaddingValues(horizontal = 12.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Rounded.Build, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Обратная связь", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun ProjectScreen(work: Work, onRead: () -> Unit, onNotes: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(work.kind.uppercase(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(work.title, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                Text(work.subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
        Text("Раздел проекта", style = MaterialTheme.typography.titleMedium)
        ListItem(headlineContent = { Text("Читать") }, supportingContent = { Text("Открыть сохранённые главы и добавить новые") }, leadingContent = { Icon(Icons.Rounded.MenuBook, null) }, modifier = Modifier.fillMaxWidth())
        Button(onClick = onRead, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.MenuBook, null); Spacer(Modifier.width(8.dp)); Text("Открыть чтение") }
        OutlinedButton(onClick = onNotes, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.BookmarkBorder, null); Spacer(Modifier.width(8.dp)); Text("Мои заметки") }
        Text("Содержимое, которое ещё не добавлено в приложение, не подменяется демонстрационными главами.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun CharactersScreen(search: String, onSearch: (String) -> Unit) {
    val filtered = characterNames.filter { it.contains(search, ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Поиск персонажа") }, leadingIcon = { Icon(Icons.Rounded.Search, null) }, shape = RoundedCornerShape(28.dp))
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered) { name -> Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                ListItem(headlineContent = { Text(name, fontWeight = FontWeight.Medium) }, supportingContent = { Text(when (name) { "Пека" -> "Главный герой Gold World"; "Шторм", "Алексей", "Элли Рояль", "Ред", "Тревор" -> "Главный герой Gold World"; "Эреб" -> "Антагонист Gold Child"; else -> "Персонаж" }) }, leadingContent = { Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.secondaryContainer) { Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Person, null, tint = MaterialTheme.colorScheme.onSecondaryContainer) } } })
            } }
            if (filtered.isEmpty()) item { EmptyState("Ничего не найдено", "Попробуй изменить запрос.") }
        }
    }
}

@Composable
private fun HistoryScreen(items: List<Pair<String, String>>, title: String, onTitle: (String) -> Unit, body: String, onBody: (String) -> Unit, onSave: () -> Unit, onDelete: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Сохраняй свои сюжетные идеи на устройстве.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = title, onValueChange = onTitle, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Название истории") }, shape = RoundedCornerShape(20.dp))
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = body, onValueChange = onBody, modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp), label = { Text("Текст или идея") }, minLines = 4, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences), shape = RoundedCornerShape(20.dp))
        Spacer(Modifier.height(8.dp))
        Button(onClick = onSave, enabled = title.isNotBlank() && body.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Сохранить запись") }
        Spacer(Modifier.height(16.dp))
        Text("Сохранённые истории · ${items.size}", style = MaterialTheme.typography.titleMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(items, key = { it.first + it.second }) { (t, b) -> Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) { Column(Modifier.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(t, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f)); IconButton(onClick = { onDelete(t) }) { Icon(Icons.Rounded.DeleteOutline, "Удалить", tint = MaterialTheme.colorScheme.error) } }; Text(b, style = MaterialTheme.typography.bodyMedium) } } }
            if (items.isEmpty()) item { EmptyState("Пока нет историй", "Добавь первую идею выше — она сохранится на устройстве.") }
        }
    }
}

@Composable
private fun ReadScreen(items: List<Pair<String, String>>, title: String, onTitle: (String) -> Unit, body: String, onBody: (String) -> Unit, onSave: () -> Unit, onDelete: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Добавь главу или фрагмент своей книги. Записи хранятся локально.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = title, onValueChange = onTitle, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Название главы") }, shape = RoundedCornerShape(20.dp))
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = body, onValueChange = onBody, modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp), label = { Text("Текст главы") }, minLines = 5, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences), shape = RoundedCornerShape(20.dp))
        Spacer(Modifier.height(8.dp))
        Button(onClick = onSave, enabled = title.isNotBlank() && body.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Сохранить главу") }
        Spacer(Modifier.height(16.dp))
        Text("Мои главы · ${items.size}", style = MaterialTheme.typography.titleMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(items, key = { it.first + it.second }) { (t, b) -> Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) { Column(Modifier.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(t, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f)); IconButton(onClick = { onDelete(t) }) { Icon(Icons.Rounded.DeleteOutline, "Удалить", tint = MaterialTheme.colorScheme.error) } }; Text(b, style = MaterialTheme.typography.bodyMedium) } } }
            if (items.isEmpty()) item { EmptyState("Глав пока нет", "Здесь появятся главы, которые ты добавишь. Приложение не содержит выдуманных текстов.") }
        }
    }
}

@Composable
private fun NotesScreen(items: List<Pair<String, String>>, onDelete: (String) -> Unit) {
    if (items.isEmpty()) Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) { EmptyState("Нет заметок", "Создай первую сюжетную заметку в разделе «История».") }
    else LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { items(items, key = { it.first + it.second }) { (title, body) -> Card(shape = RoundedCornerShape(20.dp)) { ListItem(headlineContent = { Text(title) }, supportingContent = { Text(body) }, trailingContent = { IconButton(onClick = { onDelete(title) }) { Icon(Icons.Rounded.DeleteOutline, "Удалить") } }) } } }
}

@Composable
private fun FeedbackScreen(subject: String, onSubject: (String) -> Unit, body: String, onBody: (String) -> Unit, onSend: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(24.dp)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Build, null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(12.dp)); Column { Text("Обратная связь", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSecondaryContainer); Text("Идеи, ошибки и предложения", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSecondaryContainer) } } }
        OutlinedTextField(value = subject, onValueChange = onSubject, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Тема") }, shape = RoundedCornerShape(20.dp))
        OutlinedTextField(value = body, onValueChange = onBody, modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp), label = { Text("Сообщение") }, minLines = 5, shape = RoundedCornerShape(20.dp))
        Button(onClick = onSend, enabled = subject.isNotBlank() && body.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Send, null); Spacer(Modifier.width(8.dp)); Text("Написать разработчику") }
        Text("Откроется почтовое приложение с подготовленным письмом на redprofeedback@gmail.com. Перед отправкой можно всё проверить.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyState(title: String, message: String) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainerLow, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Rounded.BookmarkBorder, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
