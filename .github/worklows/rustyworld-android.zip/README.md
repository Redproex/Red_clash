# Ржавый мир — Android app

Native Android application built with Kotlin, Jetpack Compose and Material 3. Expressive-friendly rounded components, light-only blue color scheme, and responsive portrait layout.

## Features
- Home screen for RED_CLASH of RED_PARK, The Rusty World, Gold Child and Gold World.
- Searchable character directory using the established project characters.
- Create, read, and delete story notes and chapter fragments. Data is persisted locally with Preferences DataStore.
- Feedback form prepares an email to `redprofeedback@gmail.com`; the user reviews/sends it in their mail app.
- Empty states rather than fabricated book chapters.

## Build
Requires JDK 17, Android SDK platform 36, and Gradle 8.13:

```bash
gradle assembleDebug
gradle assembleRelease
```

## Signed APK through GitHub Actions
The workflow at `.github/workflows/build-release.yml` can be run from the repository's **Actions** tab using **Build signed Android release → Run workflow**. It produces a signed APK artifact.

**Signing note:** the included workflow creates a temporary signing key on each run. The resulting APK is installable, but a later release signed with a new temporary key will not update that installation in place. For ongoing releases, configure a persistent keystore and store its credentials in GitHub Actions secrets.
